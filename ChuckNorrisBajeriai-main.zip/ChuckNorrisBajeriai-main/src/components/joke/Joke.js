const Joke =()=>{
    return(
        <h2>Joke</h2>
    )
}
export default Joke