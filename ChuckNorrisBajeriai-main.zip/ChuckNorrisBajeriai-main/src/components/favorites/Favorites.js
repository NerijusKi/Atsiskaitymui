const Favorites = ()=>{
    return(
        <h2>Mano juokeliai</h2>
    )
}
export default Favorites