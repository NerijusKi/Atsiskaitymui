const Search = ()=>{
    return(
        <h2>Search</h2>
    )
}
export default Search