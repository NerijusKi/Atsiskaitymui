import {Container} from "react-bootstrap";
import Search from "../Search/Search";
import Home from "../Home/Home";

function App() {
  return (
    <Container>
      <Home/>
    </Container>
  );
}

export default App;
